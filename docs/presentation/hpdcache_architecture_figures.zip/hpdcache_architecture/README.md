# Cache 控制器微架构对照图：PPT 使用说明

这组图用于介绍两个已经实现的改动：**miss 接收/发送解耦**，以及
**S1 load hit 完成与 refill 授权重叠**。第 1 页保留上游架构图作为背景，
第 2–5 页是根据当前 RTL 核查后绘制的简化图，不能当作上游官方设计文档。

## 文件与使用方式

展示材料已生成：5 页可编辑 PPT、5 页 PDF 预览、9 张 SVG 和 9 张 PNG。
SVG/PNG 与原生 PPT 形状由 [build_diagrams.py](build_diagrams.py) 共用一套布局生成；
PDF 由 PPT 导出，并检查了中文显示、箭头和文字排版。

| 文件 | 使用方式 |
|---|---|
| [hpdcache_architecture_comparison.pptx](hpdcache_architecture_comparison.pptx) | 复制所需页面到自己的项目介绍中；新绘框图使用原生 PPT 形状和文字 |
| [hpdcache_architecture_comparison.pdf](hpdcache_architecture_comparison.pdf) | 快速预览或分享排版固定的版本 |
| [01_upstream_overview.svg](figures/01_upstream_overview.svg) / [PNG](figures/01_upstream_overview.png) | 上游架构总览及旁侧说明；官方原图本体保持原样 |
| [02_modified_overview.svg](figures/02_modified_overview.svg) / [PNG](figures/02_modified_overview.png) | 修改后的读 miss/refill 路径总览，标出两处改动 |
| [03_miss_issue_comparison.svg](figures/03_miss_issue_comparison.svg) / [PNG](figures/03_miss_issue_comparison.png) | Miss 接收/发送解耦：原设计与修改后对照 |
| [04_refill_grant_comparison.svg](figures/04_refill_grant_comparison.svg) / [PNG](figures/04_refill_grant_comparison.png) | Refill 授权：原设计与修改后对照 |
| [05_refill_timing.svg](figures/05_refill_timing.svg) / [PNG](figures/05_refill_timing.png) | Hit 与 refill 的周期关系，解释何时节省一拍 |

需要单独排版前后两图时，可使用四张独立裁图：

- 原 miss 发送：[03a_miss_before.svg](figures/03a_miss_before.svg) / [PNG](figures/03a_miss_before.png)
- 解耦后发送：[03b_miss_after.svg](figures/03b_miss_after.svg) / [PNG](figures/03b_miss_after.png)
- 原 refill 授权：[04a_refill_before.svg](figures/04a_refill_before.svg) / [PNG](figures/04a_refill_before.png)
- 提前授权：[04b_refill_after.svg](figures/04b_refill_after.svg) / [PNG](figures/04b_refill_after.png)

优先复制可编辑的 PPT 页面；现代 PowerPoint 也可直接插入 SVG 保持放大清晰。
PNG 用于兼容性更好的图片插入。官方原图作为原始资产保留，不承诺其中的节点能像
新绘页面一样逐个编辑。移动到另一台电脑后，应检查中文字体和长标签是否仍完整。
字体为 Noto Sans CJK SC（思源黑体兼容字体）；缺少字体时可使用 PNG 保持排版。

整套材料也可从 [ZIP 包](hpdcache_architecture_figures.zip) 下载。单独解压展示包后，
源码的相对链接需要回到本仓库中访问。

## 重新生成

需要 Python 的 `python-pptx`、`Pillow`，以及 Inkscape；PDF 导出另需 LibreOffice。
从仓库根目录运行：

```bash
python3 docs/presentation/build_diagrams.py
soffice --headless --convert-to pdf --outdir docs/presentation \
  docs/presentation/hpdcache_architecture_comparison.pptx
```

第 1 页的官方图嵌入为完整图片，其余页的模块、箭头和文字可在 PPT 中单独修改。
SVG 中也保留矢量形状与文字；PNG 整页为 3200 × 1800，独立裁图宽 2000 像素。

## 五页的讲解顺序与约 30 秒讲稿

### 第 1 页：先建立原设计的整体认识

> 这是 CV-HPDcache 的上游架构图。它已经支持多个未完成请求：命中请求通过流水线
> 返回，缺失请求由 miss handler 跟踪，暂时不能执行的请求进入 RTAB 等待重放。
> 我的工作以这个设计为基线，重点检查 miss 请求向外发送，以及返回数据接管流水线
> 这两个环节中是否存在可以减少的等待。

指图时只需说明 Controller、MSHR/miss handler、RTAB、Cache RAM 和内存接口。
上游图展示的是 HPDcache 的 core partition，按原文档说明不包含请求端仲裁器，
不要将它称为完整 SoC 或完整加速器框图。

### 第 2 页：两处修改分别发生在哪里

> 修改主要位于两处。第一处是在 miss handler 内加入有限深度的发送元数据队列，
> 让新 miss 的接收不必始终等待上一笔向外发送完成。第二处是在控制器内调整
> refill 的授权条件，让一个安全的 S1 命中响应可以和 refill 授权在同一拍完成。
> 这两处分别减少发送侧和返回侧的内部等待。

该页用于定位，不必逐条解释所有箭头。MSHR 仍为 8 项，RTAB 仍为 4 项。
图中省略的写缓冲、AMO/uncached、CMO、flush 和 scrub 等独立路径仍保留在 RTL 中；
图的简化不表示删除了这些功能。

### 第 3 页：为何要解耦 miss 接收与发送

> 原设计虽然有多个 MSHR，但发送通路只有一项待发送元数据和 IDLE/SEND 状态机。
> 当上一笔请求停在 SEND 等待下游时，新 miss 可能需要进入 RTAB。修改后，S2 分配
> MSHR 的同时把发送元数据放入两项 FIFO。只要下一拍还有信用，就可以接收另一笔
> miss；队列满时仍然回退，因而能吸收一部分短时反压。

图中的信用是为 **S1 决策后下一拍的 S2 入队**预留的空间，包含本拍既有 S2 分配和
本拍出队的影响。新增 FIFO 总深度为 2，替代原来的一项待发送保存结构；每个队列项
已经占用一个既有 MSHR，只保存行地址及 MSHR 编号等发送元数据，不保存 cacheline。

### 第 4 页：为什么命中响应可以和 refill 授权重叠

> 第二处等待来自 refill 准入。原设计要求 S1 已经空闲，即使当拍只是一个可以正常
> 返回的 load hit，也要再等一拍。我增加了受条件约束的授权路径：当前 hit 完成响应，
> 同拍允许 refill 读取并确认 MSHR；真正的 refill 数据写入在下一拍发生。异常、重放
> 或后续阶段还有副作用时，仍使用原来的路径。

前后图保留相同的回填数据通路。新逻辑改变授权条件，没有增加数据端口，也不是让
两份数据同时占用同一个 SRAM 端口。若展示本轮性能数字，比较基线是**两边均已开启
miss 解耦，只切换提前授权**，不能将其写成相对未经修改的上游版本的收益。

### 第 5 页：用周期图解释这一拍是如何省下来的

> 在低延迟配置下，命中 load 的 SRAM 读取发生在前一拍，所以当前拍已经可以返回
> 响应。原流程这拍仍让 refill 等待，下拍才授权；修改后把授权提前到当前拍，因此
> refill 数据写入和目录更新也能相应提前。数据与目录写入仍分别占一拍，S0 在授权拍
> 不接收新请求。只有满足安全条件的重叠机会才有这个收益。

周期图是选定条件下的机制示例，不表示每次 miss 都节省一拍，也不表示整个 Cache
每拍都能接收一个新 miss。后续是否能立即接收 core 请求，还受 RTAB 等原有仲裁条件
影响；“可恢复流水线”也可能先服务 replay。

## 两项改动的准确边界

**Miss 接收/发送解耦**

- 原设计支持多个未完成 miss；瓶颈是发送 FSM 与新 miss 准入的耦合。
- S2 同时分配既有 MSHR 并入队发送元数据，不能画成发送时才分配 MSHR。
- `count_next = count + alloc - pop`，`alloc_ready = count_next < 2`。
- FIFO 总容量为两项，不是新增两个 MSHR；队列满时仍会造成等待。
- 出队仍依赖下游 ready，信用也考虑当拍出队；该改动没有完全切断 ready 的影响。
- 其他流水线气泡、同线依赖、MSHR/RTAB 满等条件仍然存在。

**Refill 提前授权**

- 只允许正常 cacheable core load hit 完成响应时使用新重叠路径；回填元数据需要
  有效且不是 invalidation/error refill。
- 排除 replay 来源、错误/abort、ECC 恢复、RTAB 分配、已有或新产生的 S2
  MSHR/目录/flush 工作，以及相关控制器占用等情况。
- 初始配置限制为 lowLatency、response feedthrough、MSHR regbank、整行一拍
  refill 和单字 core 请求。不支持的配置保持原规则。
- 授权拍 S0 不接受新 core/replay 请求，下一拍 S1 清空；hit 与 refill 响应分拍。
- 同线 refill 直接完成功能在本轮关闭。它是另一项实验，不应与提前授权画成同一机制。

## 源码、来源与结果

| 内容 | 仓库依据 |
|---|---|
| 上游官方总览图 | [hpdcache_core.svg](../source/images/hpdcache_core.svg) |
| 官方架构及流水线说明 | [architecture.rst](../source/architecture.rst) |
| 原始发送 FSM、解耦连接及 refill FSM | [hpdcache_miss_handler.sv](../../rtl/src/hpdcache_miss_handler.sv)；`gen_legacy_issue`、`gen_decoupled_issue`、`miss_resp_fsm_comb` |
| 两项 FIFO 与信用判断 | [hpdcache_miss_issue_queue.sv](../../rtl/src/hpdcache_miss_issue_queue.sv) |
| S1 准入/RTAB 回退及提前授权条件 | [hpdcache_ctrl_pe.sv](../../rtl/src/hpdcache_ctrl_pe.sv)；`st1_mshr_alloc_ready_i`、`EARLY_GRANT_SUPPORTED`、`refill_early_grant` |
| S2 寄存、响应选择与断言 | [hpdcache_ctrl.sv](../../rtl/src/hpdcache_ctrl.sv) |
| Miss 解耦的真实矩阵评估 | [real/RESULTS.md](../../rtl/tb/tests/miss_issue_research/real/RESULTS.md) |
| 提前授权机制、配置与复现 | [EARLY_GRANT.md](../../rtl/tb/tests/miss_issue_research/EARLY_GRANT.md) |
| 提前授权应用与因果结果 | [EARLY_GRANT_RESULTS.md](../../rtl/tb/tests/miss_issue_research/EARLY_GRANT_RESULTS.md) |
| 匹配 PPA 结果 | [EARLY_GRANT_PPA.md](../../rtl/syn/refill_direct/EARLY_GRANT_PPA.md) |

上游原图与架构文档来自本仓库所保留的 OpenHW CV-HPDcache 文档，保留其作者与授权
归属，附有 [上游 LICENSE 副本](assets/UPSTREAM_LICENSE.txt)。修改后的图是本项目依据
RTL 绘制的讲解材料，没有声称为 OpenHW 官方修改图。
对未画出的控制条件，应以上述 RTL 和完整机制文档为准。
