#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0 WITH SHL-2.1
"""Generate RTL-reviewed, editable PPTX and vector/raster architecture figures.
Run from any cwd: python3 docs/presentation/build_diagrams.py
Requires python-pptx, Pillow and Inkscape. Optional PDF export uses LibreOffice.
"""
import base64
import html
import json
from pathlib import Path
import shutil
import subprocess

from PIL import ImageFont
from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE, MSO_CONNECTOR
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.enum.dml import MSO_LINE_DASH_STYLE
from pptx.oxml.xmlchemy import OxmlElement
from pptx.oxml.ns import qn
from pptx.util import Inches, Pt

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
FIG = OUT / 'figures'
ASSETS = OUT / 'assets'
FIG.mkdir(exist_ok=True); ASSETS.mkdir(exist_ok=True)
W,H = 1600,900
FONT = 'Noto Sans CJK SC'
C = dict(bg='F5F7FB', ink='17253E', muted='53657F', border='D6E0EC', white='FFFFFF',
         blue='2862BE', bluefill='EDF3FF', grey='738298', greyfill='F0F3F7',
         green='087F67', greenfill='E7F6EF', amber='AE5D0D', amberfill='FFF1DE')
FONT_REG='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'
FONT_BOLD='/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc'

def esc(s):return html.escape(str(s))
def rgb(c):return RGBColor.from_string(C.get(c,c))
def color(c):return '#'+C.get(c,c)
def inch(px):return Inches(px/120)

def no_effects(shape):
    # Override the template's theme shadow so native slides match the flat SVGs.
    shape._element.spPr.append(OxmlElement('a:effectLst'))
    style=shape._element.find(qn('p:style'))
    if style is not None:
        effect=style.find(qn('a:effectRef'))
        if effect is not None:effect.set('idx','0')

def check_width(lines, size, width, bold=False):
    font=ImageFont.truetype(FONT_BOLD if bold else FONT_REG, int(size))
    for line in lines:
        actual=font.getlength(line)
        if actual > width+5:
            raise ValueError(f'Text overflows ({actual:.0f}>{width}): {line}')

class Canvas:
    def __init__(self,name,title,subtitle,page,notes=''):
        self.name=name;self.ops=[];self.notes=notes
        self.rect(0,0,W,H,'bg',None,0)
        self.rect(48,49,8,54,'green',None,0)
        self.text(78,45,1460,title,44,bold=True)
        self.text(80,112,1440,subtitle,25,'muted')
        self.text(80,856,1380,'CV-HPDcache  |  基于当前 RTL 的项目示意；非物理版图  |  '+page,19,'muted')
        self.text(1470,852,70,page,24,'grey',align='right')
    def rect(self,x,y,w,h,fill='white',stroke='border',radius=14,width=1.5):
        self.ops.append(dict(type='rect',x=x,y=y,w=w,h=h,fill=fill,stroke=stroke,radius=radius,width=width))
    def text(self,x,y,w,txt,size=27,fill='ink',bold=False,align='left'):
        lines=txt.split('\n');check_width(lines,size,w,bold)
        self.ops.append(dict(type='text',x=x,y=y,w=w,h=len(lines)*size*1.3+6,lines=lines,size=size,fill=fill,bold=bold,align=align))
    def node(self,x,y,w,h,title,detail='',tone='blue',size=27):
        self.rect(x,y,w,h,tone+'fill',tone,12,1.7)
        n=len(title.split('\n'));ht=n*size*1.3+(len(detail.split('\n'))*21*1.3+6 if detail else 0)
        yy=y+(h-ht)/2
        self.text(x+12,yy,w-24,title,size,tone,True,'center')
        if detail:self.text(x+10,yy+n*size*1.3+6,w-20,detail,21,'muted',align='center')
    def path(self,points,tone='grey',dash=False,width=2.5,arrow=True,both=False):
        self.ops.append(dict(type='path',points=points,tone=tone,dash=dash,width=width,arrow=arrow,both=both))
    def label(self,x,y,w,txt,tone='muted',size=21):
        self.rect(x-3,y-1,w+6,size*1.3+5,'white',None,2)
        self.text(x,y,w,txt,size,tone,align='center')
    def pill(self,x,y,w,txt,tone='green'):
        self.rect(x,y,w,38,tone+'fill',None,9)
        self.text(x+8,y+3,w-16,txt,22,tone,True,'center')
    def panel(self,x,title,sub,tone='grey'):
        self.rect(x,180,740,634,'white','border',18)
        self.text(x+26,197,688,title,30,tone,True)
        self.text(x+26,232,688,sub,20,'muted')
    def picture(self,x,y,w,h,path,svg=None):
        self.ops.append(dict(type='picture',x=x,y=y,w=w,h=h,path=str(path),svg=str(svg) if svg else None))
    def svg(self,view=(0,0,W,H)):
        x0,y0,vw,vh=view
        out=[f'<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="{vw}" height="{vh}" viewBox="{x0} {y0} {vw} {vh}">',
             '<defs>']
        for tone in ['grey','green','blue','amber','ink']:
            out.append(f'<marker id="arrow-{tone}" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="9" markerHeight="9" orient="auto-start-reverse"><path d="M 0 0 L 10 5 L 0 10 z" fill="{color(tone)}"/></marker>')
        out.append('</defs>')
        for o in self.ops:
            t=o['type']
            if t=='rect':
                stroke=color(o['stroke']) if o['stroke'] else 'none'
                out.append(f'<rect x="{o["x"]}" y="{o["y"]}" width="{o["w"]}" height="{o["h"]}" rx="{o["radius"]}" fill="{color(o["fill"])}" stroke="{stroke}" stroke-width="{o["width"]}"/>')
            elif t=='text':
                xx=o['x']+(o['w']/2 if o['align']=='center' else o['w'] if o['align']=='right' else 0)
                anchor={'left':'start','center':'middle','right':'end'}[o['align']]
                for i,line in enumerate(o['lines']):
                    yy=o['y']+o['size']*.96+i*o['size']*1.3
                    out.append(f'<text x="{xx}" y="{yy}" font-family="{FONT}, sans-serif" font-size="{o["size"]}" font-weight="{700 if o["bold"] else 400}" fill="{color(o["fill"])}" text-anchor="{anchor}">{esc(line)}</text>')
            elif t=='path':
                pts=' '.join(f'{x},{y}' for x,y in o['points'])
                dash=' stroke-dasharray="8 6"' if o['dash'] else ''
                arrow=f' marker-end="url(#arrow-{o["tone"]})"' if o['arrow'] else ''
                if o['both']:arrow+=f' marker-start="url(#arrow-{o["tone"]})"'
                out.append(f'<polyline points="{pts}" fill="none" stroke="{color(o["tone"])}" stroke-width="{o["width"]}" stroke-linejoin="round"{dash}{arrow}/>')
            elif t=='picture':
                raw=Path(o['svg']).read_bytes() if o['svg'] else Path(o['path']).read_bytes()
                mime='image/svg+xml' if o['svg'] else 'image/png'
                data=base64.b64encode(raw).decode()
                out.append(f'<image x="{o["x"]}" y="{o["y"]}" width="{o["w"]}" height="{o["h"]}" preserveAspectRatio="xMidYMid meet" xlink:href="data:{mime};base64,{data}"/>')
        return '\n'.join(out+['</svg>'])
    def ppt(self,prs):
        slide=prs.slides.add_slide(prs.slide_layouts[6])
        for o in self.ops:
            t=o['type']
            if t=='rect':
                shape=slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE if o['radius'] else MSO_SHAPE.RECTANGLE,inch(o['x']),inch(o['y']),inch(o['w']),inch(o['h']))
                no_effects(shape)
                if o['radius']:
                    shape.adjustments[0]=min(.15,o['radius']/min(o['w'],o['h']))
                shape.fill.solid();shape.fill.fore_color.rgb=rgb(o['fill'])
                if o['stroke']:
                    shape.line.color.rgb=rgb(o['stroke']);shape.line.width=Pt(o['width']*.6)
                else:shape.line.fill.background()
            elif t=='text':
                shape=slide.shapes.add_textbox(inch(o['x']),inch(o['y']),inch(o['w']),inch(o['h']))
                tf=shape.text_frame;tf.clear();tf.word_wrap=False
                tf.margin_left=tf.margin_right=tf.margin_top=tf.margin_bottom=0
                tf.vertical_anchor=MSO_ANCHOR.TOP
                for i,line in enumerate(o['lines']):
                    p=tf.paragraphs[0] if i==0 else tf.add_paragraph()
                    p.alignment={'left':PP_ALIGN.LEFT,'center':PP_ALIGN.CENTER,'right':PP_ALIGN.RIGHT}[o['align']]
                    p.space_before=Pt(0);p.space_after=Pt(0);p.line_spacing=Pt(o['size']*.6*1.3)
                    run=p.add_run();run.text=line
                    run.font.name=FONT;run.font.size=Pt(o['size']*.6);run.font.bold=o['bold'];run.font.color.rgb=rgb(o['fill'])
                    ea=OxmlElement('a:ea');ea.set('typeface',FONT);run._r.get_or_add_rPr().append(ea)
            elif t=='path':
                for i,(a,b) in enumerate(zip(o['points'],o['points'][1:])):
                    sh=slide.shapes.add_connector(MSO_CONNECTOR.STRAIGHT,inch(a[0]),inch(a[1]),inch(b[0]),inch(b[1]))
                    no_effects(sh)
                    sh.line.color.rgb=rgb(o['tone']);sh.line.width=Pt(o['width']*.6)
                    if o['dash']:sh.line.dash_style=MSO_LINE_DASH_STYLE.DASH
                    if o['arrow'] and i==len(o['points'])-2:
                        end=OxmlElement('a:tailEnd');end.set('type','triangle');end.set('w','sm');end.set('len','sm');sh.line._get_or_add_ln().append(end)
                    if o['both'] and i==0:
                        start=OxmlElement('a:headEnd');start.set('type','triangle');start.set('w','sm');start.set('len','sm');sh.line._get_or_add_ln().append(start)
            elif t=='picture':slide.shapes.add_picture(o['path'],inch(o['x']),inch(o['y']),width=inch(o['w']),height=inch(o['h']))
        slide.notes_slide.notes_text_frame.text=self.notes
        return slide

upstream=ROOT/'docs/source/images/hpdcache_core.svg'
shutil.copy2(upstream,ASSETS/'upstream_hpdcache_core.svg')
shutil.copy2(ROOT/'LICENSE',ASSETS/'UPSTREAM_LICENSE.txt')
png=ASSETS/'upstream_hpdcache_core.png'
if not png.exists():
    subprocess.run(['inkscape',str(upstream),'--export-type=png',f'--export-filename={png}','--export-width=2400'],check=True,capture_output=True)
slides=[]

s=Canvas('01_upstream_overview','原项目：CV-HPDcache 总体微架构','上游官方架构图；本项目定位在 Miss Handler 与流水线授权控制两处。','01',
'''官方图来自 docs/source/images/hpdcache_core.svg，说明见 docs/source/architecture.rst。OpenHW CV-HPDcache / CEA。
图示 core partition 不含上层 requester arbitration。请求进入三阶段流水线；miss由Miss Handler处理，等待的请求进入RTAB。
改动A位于Miss Handler发送路径；改动B位于refill与Cache Controller之间的grant控制。原图未修改。
不将上游Cache整体实现计为本项目从零设计。''')
s.rect(50,182,1050,635,'white','border',18)
s.picture(65,201,1020,607.325,png,upstream)
s.node(1140,205,405,240,'A  发送路径','Miss Handler 内部\n发送状态会影响新 miss 准入\n详见第 3 页','amber',31)
s.node(1140,485,405,240,'B  回填授权','Refill → 流水线仲裁\nS1 未空时需要继续等待\n详见第 4–5 页','amber',31)
s.text(1145,748,395,'原图来源：OpenHW / CEA\ndocs/source/images/\nhpdcache_core.svg',21,'muted')
slides.append(s)

s=Canvas('02_modified_overview','修改后：两处调度改造的集成视图','简化读路径；绿色表示新增或修改逻辑。原有写缓冲、AMO / CMO 等独立路径未展开。','02',
'''这是按当前RTL整理的简化集成图，不是替换上游官方全架构图。
A：S2同时分配现有MSHR和2-entry发送元数据FIFO，每项已经占用MSHR；队头通过原有请求仲裁发出。
B：refill grant保留原有空S1路径，并为满足安全条件的S1普通core load hit增加重叠授权资格。
授权当拍不写refill数据，Data/Directory仍分拍，S0不接收新请求。MSHR=8和RTAB=4保持不变。
原型参数MissIssueDecoupleEnable=1,RefillEarlyGrantEnable=1,RefillDirectEnable=0。''')
s.node(420,180,480,70,'Core / SpMV 行为执行模型',tone='grey',size=29)
s.rect(70,300,940,245,'white','border',18)
s.text(650,315,325,'Cache Controller',28,bold=True)
s.node(100,370,240,80,'S0 仲裁','Core / RTAB / Refill',size=28)
s.node(380,370,250,80,'S1 查询与响应','hit / miss / 异常判断',size=28)
s.node(675,370,295,80,'S2 分配','MSHR + 待发元数据',size=28)
s.path([(340,410),(380,410)],'blue');s.path([(630,410),(675,410)],'blue')
s.node(100,475,530,50,'B  安全 hit 完成 → 可提前授予 refill',tone='green',size=25)
s.path([(540,250),(540,275),(220,275),(220,370)],'blue')
s.path([(505,370),(505,287),(770,287),(770,250)],'blue',True)
s.label(570,262,145,'命中响应',size=21)
s.node(90,610,250,105,'RTAB · 4 entries','等待与重放',tone='grey',size=25)
s.path([(215,610),(215,545)],'blue')
s.node(420,610,550,105,'Cache Directory / Data RAM','读命中、refill 数据写入、目录更新',tone='blue',size=29)
s.path([(690,545),(690,610)],'blue')
s.rect(1060,300,470,415,'white','border',18)
s.text(1085,315,415,'Miss Handler',29,bold=True)
s.node(1090,365,410,72,'MSHR · 8 entries','跟踪已分配 miss',tone='grey',size=27)
s.node(1090,465,410,90,'A  2-entry 发送元数据 FIFO','{nline, MSHR way} + 准入信用',tone='green',size=25)
s.node(1090,610,410,75,'Refill FIFO + FSM','原有返回与安装通路',tone='blue',size=27)
s.path([(970,410),(1028,410),(1028,400),(1090,400)],'blue')
s.path([(1028,410),(1028,510),(1090,510)],'green')
s.path([(1090,650),(990,650),(990,575),(320,575),(320,525)],'green',True,both=True)
s.label(515,557,440,'refill request / grant（控制交互）','green',21)
s.path([(1090,671),(1010,671),(1010,700),(970,700)],'blue')
s.node(1090,765,410,60,'读请求仲裁器 / 下一级存储',tone='grey',size=25)
s.path([(1450,555),(1550,555),(1550,795),(1500,795)],'green')
s.label(1430,723,130,'读请求','green',21)
s.path([(1185,765),(1185,715),(1185,685)],'blue')
s.label(1205,719,150,'返回数据',size=21)
s.text(88,757,910,'两处改动改变调度时机；图中 MSHR 与 RTAB 容量仍为 8 / 4。',24,'muted')
s.text(88,795,910,'实线：请求 / 数据与操作方向   虚线：控制或响应；未展开全部端口连线。',22,'muted')
slides.append(s)

s=Canvas('03_miss_issue_comparison','改动 1：miss 接收与发送解耦','已有多个 MSHR，但发送通路的暂存与准入能力仍可能受到下游反压限制。','03',
'''原设计：Miss Request FSM只有IDLE/SEND。IDLE接受S2分配并保存一项{nline,MSHR way}；SEND保持valid，但alloc_ready始终为0，握手后下一拍才回IDLE。
修改：以2-entry元数据FIFO替代原单项保存结构和发送状态控制。S2分配MSHR与FIFO入队同拍发生；队头握手后pop。
准入反馈面向S1，承诺下一拍S2空间：count_next=count+当前alloc-当前pop，alloc_ready=count_next<2。不是FIFO本拍wok。
队列所有项已经占用MSHR；满时仍会hold到RTAB。不是增加两个MSHR、不是完全切断ready，不承诺整个Cache每拍新miss。
省略请求组包细节和RTAB返回S1的重放连线。''')
for x,on in [(40,False),(820,True)]:
    tone='green' if on else 'amber'
    s.panel(x,'修改后｜有限队列吸收发送反压' if on else '原设计｜发送状态限制新 miss 准入',
            'MissIssueDecoupleEnable = 1' if on else 'MissIssueDecoupleEnable = 0',tone)
    a=x+40;b=x+410
    s.node(a,290,245,75,'S1 miss 准入检查',size=25)
    s.node(b,290,275,75,'RTAB · 4 entries','未 ready 时等待',tone='grey',size=25)
    s.path([(a+245,327),(b,327)],'amber')
    s.label(a+253,296,110,'hold','amber',20)
    s.node(a,420,245,70,'S2 分配',size=27)
    s.node(b,420,275,70,'MSHR · 8 entries','容量不变',tone='grey',size=25)
    s.path([(a+122,365),(a+122,420)],'blue');s.label(a+132,382,105,'准入通过',size=20)
    s.path([(a+245,455),(b,455)],'blue');s.label(a+252,423,110,'分配',size=20)
    s.node(a,550,380,95,'2-entry 元数据 FIFO' if on else '单项待发元数据寄存器',
           '{nline, MSHR way}',tone=tone,size=25)
    s.node(x+500,550,185,95,'下一拍信用' if on else 'IDLE / SEND',
           'count_next < 2' if on else '发送状态机',tone=tone,size=23)
    s.path([(a+122,490),(a+122,550)],'blue');s.label(a+132,508,170,'同拍分配并入队' if on else '同拍保存信息',size=20)
    s.path([(a+380,597),(x+500,597)],tone,True)
    s.path([(x+685,590),(x+715,590),(x+715,277),(a+122,277),(a+122,290)],tone,True)
    s.label(x+285,256,410,'准入 ready：依据下一拍信用' if on else '准入 ready：SEND 时为 0',tone,20)
    s.node(a,700,645,58,'读请求仲裁器 / 下一级存储接口',tone='grey',size=25)
    s.path([(a+155,645),(a+155,700)],'blue')
    s.label(a+170,662,180,'队头请求 / valid' if on else '待发请求信息',size=20)
    if not on:
        s.path([(x+525,645),(x+525,700)],'amber',True)
        s.label(x+460,660,65,'valid','amber',19)
    s.path([(x+600,700),(x+600,645)],tone,True)
    s.label(x+602,660,105,'ready',tone,20)
    if on:
        s.path([(x+600,675),(a+365,675),(a+365,645)],'green',True)
    s.text(a,775,650,'仍有信用时，可先接纳下一笔 miss；满时仍需等待。' if on else '发送未完成时，新 miss 可能进入 RTAB 等待。',21,tone)
s.text(82,822,1440,'新增的是待发送元数据缓冲，不存 cacheline 数据；FIFO 中的每一项已拥有一个 MSHR。',23,'ink',True)
slides.append(s)

s=Canvas('04_refill_grant_comparison','改动 2：S1 hit 完成与 refill 授权重叠','只改变 refill 的授权资格；原有数据写入、目录更新与响应通路继续使用。','04',
'''左边是原授权规则，右边增加安全的S1普通core load hit完成作为例外。本轮性能实验两边均开启miss解耦，只改变RefillEarlyGrantEnable。
安全条件含：普通可缓存core load hit，响应有效且无error/abort；无RTAB分配/重放/ECC恢复；新旧S2的MSHR/目录/flush工作都为空；无CMO/UC/error/flush竞争；refill非error非invalidation。
S0在refill pending时保持关闭，只有已经在S1的旧hit能在授权拍完成。命中响应与refill响应不在同一拍。
MSHR ack_cs原先就预使能；真正提前的是grant驱动的ack与FSM转移。不存在新增refill数据旁路或RAM端口。
静态范围lowLatency, response feedthrough, MSHR regbank,单拍整行refill,单字请求；RefillDirectEnable同时开启时本优化禁用。''')
for x,on in [(40,False),(820,True)]:
    tone='green' if on else 'amber'
    s.panel(x,'修改后｜允许安全的旧 hit 完成时授权' if on else '原设计｜S1 为空时才授权',
            'RefillEarlyGrantEnable = 1' if on else 'RefillEarlyGrantEnable = 0',tone)
    a=x+40
    s.node(a,290,290,80,'S1 普通 core load hit','已在流水线内的旧请求',size=25)
    s.node(x+425,290,260,80,'原有响应通路','hit 当拍返回 Core',tone='grey',size=25)
    s.path([(a+290,330),(x+425,330)],'blue')
    s.node(x+80,422,605,115,'Refill grant 授权控制',
           'S1 为空，或安全 hit 正在完成\n仍须满足原有授权条件' if on else '需 S1 为空 + 原有授权条件\n旧 hit 本拍响应，refill 仍等待',tone=tone,size=28)
    s.path([(a+145,370),(a+145,422)],tone,True)
    s.label(a+158,385,425,'hit / 响应 / 异常 / 新旧 S2 工作' if on else 'S1 valid 状态',tone,20)
    s.node(a,625,280,78,'Refill FIFO','返回数据与元信息',size=25)
    s.node(x+435,625,250,78,'Refill FSM','原有回填状态机',size=26)
    s.path([(a+280,663),(x+435,663)],'blue')
    s.label(a+285,630,105,'待处理',size=20)
    s.path([(x+495,625),(x+495,537)],'grey',True)
    s.label(x+390,566,120,'request',size=20)
    s.path([(x+630,537),(x+630,625)],tone,True)
    s.label(x+640,566,70,'grant',tone,20)
    if on:
        s.path([(a+140,625),(a+140,537)],'green',True)
        s.rect(a+1,556,248,56,'white',None,2)
        s.text(a+5,559,240,'提前资格\n非 error / invalidation',18,'green',align='center')
    s.node(a,747,645,45,'原有执行通路：MSHR ack → Data → Dir / RTAB',tone='grey',size=22)
    s.path([(x+560,703),(x+560,747)],'blue')
s.text(80,821,1450,'重叠的是“hit 响应 + refill 授权”；S0 仍不接收新请求，refill 数据下一拍才写入。',23,'ink',True)
slides.append(s)

s=Canvas('05_refill_timing','为什么能省一拍：授权提前，数据写入时序仍分开','例：正常、需要返回响应的 load refill；hit 的 SRAM 读取已在前一拍发起。','05',
'''此图是满足early grant资格时的相对周期示意，不代表每个refill均省一拍。需要正常load refill且需返回响应。
t：原设计hit响应并等待；优化hit响应并grant/MSHR ack。
t+1：原设计grant；优化WRITE写数据并返回原miss响应。
t+2：原设计WRITE；优化WRITE_DIR更新目录、唤醒RTAB。
t+3：原设计WRITE_DIR；优化重新仲裁，若没有其他阻塞可接收。
数据和目录仍各占一拍；RTAB唤醒没有提前到grant/数据拍；新增路径有时序成本，需STA评估。
配置范围lowLatency、单字请求、整行单拍refill、MSHR regbank和response feedthrough。''')
s.pill(80,175,1440,'只消除一次可避免的准入等待；不表示增加 SRAM 端口，也不表示两个响应同拍返回。','green')
start=310;cw=292
for j,name in enumerate(['t','t + 1','t + 2','t + 3']):
    s.text(start+j*cw,245,cw-14,name,34,'muted',True,'center')
    if j:s.path([(start+j*cw-10,292),(start+j*cw-10,686)],'grey',True,1.0,False)
s.text(80,337,200,'原授权逻辑',31,'amber',True)
s.text(80,557,200,'提前授权',31,'green',True)
old=[('hit 响应','refill 等待','amber'),('grant','MSHR ack','grey'),('DATA','写数据 + miss 响应','blue'),('DIR','目录更新 + RTAB 唤醒','blue')]
new=[('hit 响应 + grant','同拍 MSHR ack','green'),('DATA','写数据 + miss 响应','blue'),('DIR','目录更新 + RTAB 唤醒','blue'),('重新仲裁','无其他阻塞时可接收','green')]
for row,ys in [(old,310),(new,530)]:
    for j,(title,detail,tone) in enumerate(row):s.node(start+j*cw,ys,cw-22,145,title,detail,tone,28)
s.path([(start+cw+126,485),(start+126,485)],'green',False,3)
s.label(start+145,465,250,'grant 提前一拍','green',24)
s.rect(80,725,1440,90,'white','border',14)
s.text(105,740,1390,'资格检查：普通 core load hit 正常完成；无重放 / ECC 恢复；无新旧 S2 工作及其他控制器占用。',24,'ink')
s.text(105,777,1390,'原型配置：lowLatency、MSHR regbank、response feedthrough、整行单拍 refill、单字请求。',21,'muted')
slides.append(s)

prs=Presentation();prs.slide_width=inch(W);prs.slide_height=inch(H)
prs.core_properties.title='CV-HPDcache：原设计与两项微架构优化'
prs.core_properties.subject='SpMV cache controller architecture comparisons'
prs.core_properties.author='CV-HPDcache project study'
prs.core_properties.comments='Official source figure attributed in slide 1; other diagrams checked against current RTL.'
manifest=[]
for s in slides:
    path=FIG/(s.name+'.svg');path.write_text(s.svg(),encoding='utf-8')
    s.ppt(prs)
    manifest.append(dict(name=s.name,svg=str(path.relative_to(OUT)),editable=s.name!='01_upstream_overview',notes=s.notes))
prs.save(OUT/'hpdcache_architecture_comparison.pptx')
for slide_index,prefix in [(2,'03'),(3,'04')]:
    for x,suffix in [(40,'a'),(820,'b')]:
        name=prefix+suffix+('_miss_' if prefix=='03' else '_refill_')+('before' if suffix=='a' else 'after')
        (FIG/(name+'.svg')).write_text(slides[slide_index].svg((x,180,740,634)),encoding='utf-8')
(OUT/'diagram_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for p in sorted(FIG.glob('*.svg')):
    dest=p.with_suffix('.png')
    subprocess.run(['inkscape',str(p),'--export-type=png',f'--export-filename={dest}','--export-width='+('3200' if 'comparison' in p.stem or 'overview' in p.stem or 'timing' in p.stem else '2000')],check=True,capture_output=True)
print('Generated 5 native-shape slides, 9 SVGs and 9 PNGs:',OUT)
